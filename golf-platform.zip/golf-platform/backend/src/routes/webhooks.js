const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const supabase = require('../lib/supabase');

/**
 * POST /api/webhooks/stripe
 * Handle Stripe webhook events
 */
router.post('/stripe', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const userId = session.metadata?.supabase_user_id;
        const plan = session.metadata?.plan;

        if (!userId) break;

        // Fetch subscription from Stripe to get period dates
        const stripeSub = await stripe.subscriptions.retrieve(session.subscription);

        const amount = stripeSub.items.data[0].price.unit_amount / 100;
        const currency = stripeSub.currency.toUpperCase();

        await supabase.from('subscriptions').insert({
          user_id: userId,
          plan: plan || 'monthly',
          status: 'active',
          stripe_customer_id: session.customer,
          stripe_subscription_id: session.subscription,
          amount_paid: amount,
          currency,
          current_period_start: new Date(stripeSub.current_period_start * 1000).toISOString(),
          current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString()
        });

        // Calculate and log charity contribution
        const { data: profile } = await supabase
          .from('profiles')
          .select('charity_id, charity_percentage')
          .eq('id', userId)
          .single();

        if (profile?.charity_id) {
          const contributionAmount = parseFloat(
            (amount * (profile.charity_percentage / 100)).toFixed(2)
          );
          const now = new Date();

          await supabase.from('charity_contributions').insert({
            user_id: userId,
            charity_id: profile.charity_id,
            amount: contributionAmount,
            percentage: profile.charity_percentage,
            period_month: now.getMonth() + 1,
            period_year: now.getFullYear()
          });

          // Update charity total_raised
          await supabase.rpc('increment_charity_raised', {
            charity_uuid: profile.charity_id,
            increment_amount: contributionAmount
          });
        }

        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object;
        if (!invoice.subscription) break;

        const stripeSub = await stripe.subscriptions.retrieve(invoice.subscription);

        await supabase
          .from('subscriptions')
          .update({
            status: 'active',
            current_period_start: new Date(stripeSub.current_period_start * 1000).toISOString(),
            current_period_end: new Date(stripeSub.current_period_end * 1000).toISOString()
          })
          .eq('stripe_subscription_id', invoice.subscription);

        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        await supabase
          .from('subscriptions')
          .update({ status: 'cancelled', cancelled_at: new Date().toISOString() })
          .eq('stripe_subscription_id', sub.id);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        if (!invoice.subscription) break;

        await supabase
          .from('subscriptions')
          .update({ status: 'lapsed' })
          .eq('stripe_subscription_id', invoice.subscription);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook handler error:', err);
    res.status(500).json({ error: 'Webhook handler failed' });
  }
});

module.exports = router;
