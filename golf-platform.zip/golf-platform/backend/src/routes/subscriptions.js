const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const supabase = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');

// Stripe Price IDs — replace with your actual IDs from Stripe Dashboard
const PRICE_IDS = {
  monthly: process.env.STRIPE_PRICE_MONTHLY || 'price_monthly_placeholder',
  yearly: process.env.STRIPE_PRICE_YEARLY || 'price_yearly_placeholder'
};

/**
 * GET /api/subscriptions/status
 * Get authenticated user's current subscription status
 */
router.get('/status', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', req.user.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  if (error) return res.json({ subscription: null });
  res.json({ subscription: data });
});

/**
 * POST /api/subscriptions/checkout
 * Create Stripe Checkout session
 * Body: { plan: 'monthly' | 'yearly' }
 */
router.post('/checkout', requireAuth, async (req, res) => {
  const { plan } = req.body;

  if (!['monthly', 'yearly'].includes(plan)) {
    return res.status(400).json({ error: 'Invalid plan. Must be monthly or yearly.' });
  }

  // Check if user already has active subscription
  const { data: existing } = await supabase
    .from('subscriptions')
    .select('status')
    .eq('user_id', req.user.id)
    .eq('status', 'active')
    .single();

  if (existing) {
    return res.status(400).json({ error: 'You already have an active subscription.' });
  }

  // Get or create Stripe customer
  let stripeCustomerId = null;
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', req.user.id)
    .single();

  const { data: existingSub } = await supabase
    .from('subscriptions')
    .select('stripe_customer_id')
    .eq('user_id', req.user.id)
    .not('stripe_customer_id', 'is', null)
    .limit(1)
    .single();

  if (existingSub?.stripe_customer_id) {
    stripeCustomerId = existingSub.stripe_customer_id;
  } else {
    const customer = await stripe.customers.create({
      email: req.user.email,
      name: profile?.full_name || req.user.email,
      metadata: { supabase_user_id: req.user.id }
    });
    stripeCustomerId = customer.id;
  }

  const session = await stripe.checkout.sessions.create({
    customer: stripeCustomerId,
    payment_method_types: ['card'],
    line_items: [{ price: PRICE_IDS[plan], quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.FRONTEND_URL}/dashboard?subscribed=true`,
    cancel_url: `${process.env.FRONTEND_URL}/subscribe?cancelled=true`,
    metadata: {
      supabase_user_id: req.user.id,
      plan
    }
  });

  res.json({ url: session.url });
});

/**
 * POST /api/subscriptions/cancel
 * Cancel active subscription
 */
router.post('/cancel', requireAuth, async (req, res) => {
  const { data: sub } = await supabase
    .from('subscriptions')
    .select('stripe_subscription_id')
    .eq('user_id', req.user.id)
    .eq('status', 'active')
    .single();

  if (!sub?.stripe_subscription_id) {
    return res.status(404).json({ error: 'No active subscription found' });
  }

  // Cancel at period end (not immediately)
  await stripe.subscriptions.update(sub.stripe_subscription_id, {
    cancel_at_period_end: true
  });

  res.json({ message: 'Subscription will cancel at end of billing period' });
});

/**
 * POST /api/subscriptions/portal
 * Create Stripe Customer Portal session
 */
router.post('/portal', requireAuth, async (req, res) => {
  const { data: sub } = await supabase
    .from('subscriptions')
    .select('stripe_customer_id')
    .eq('user_id', req.user.id)
    .not('stripe_customer_id', 'is', null)
    .single();

  if (!sub?.stripe_customer_id) {
    return res.status(404).json({ error: 'No Stripe customer found' });
  }

  const session = await stripe.billingPortal.sessions.create({
    customer: sub.stripe_customer_id,
    return_url: `${process.env.FRONTEND_URL}/dashboard`
  });

  res.json({ url: session.url });
});

module.exports = router;
