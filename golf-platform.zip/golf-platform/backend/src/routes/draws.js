const express = require('express');
const router = express.Router();
const supabase = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/auth');
const { runDraw } = require('../services/drawEngine');

/**
 * GET /api/draws
 * List all published draws (public)
 */
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('draws')
    .select('*')
    .eq('status', 'published')
    .order('year', { ascending: false })
    .order('month', { ascending: false });

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

/**
 * GET /api/draws/latest
 * Latest published draw result
 */
router.get('/latest', async (req, res) => {
  const { data, error } = await supabase
    .from('draws')
    .select('*')
    .eq('status', 'published')
    .order('year', { ascending: false })
    .order('month', { ascending: false })
    .limit(1)
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

/**
 * GET /api/draws/:id/my-result
 * Check authenticated user's result for a specific draw
 */
router.get('/:id/my-result', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('draw_participants')
    .select('*, winners(*)')
    .eq('draw_id', req.params.id)
    .eq('user_id', req.user.id)
    .single();

  if (error) return res.status(404).json({ error: 'Not found' });
  res.json(data);
});

/**
 * POST /api/draws/simulate (Admin)
 * Run a simulation without saving winners
 */
router.post('/simulate', requireAuth, requireAdmin, async (req, res) => {
  const { draw_id, logic } = req.body;

  const { data: draw } = await supabase
    .from('draws')
    .select('*')
    .eq('id', draw_id)
    .single();

  if (!draw) return res.status(404).json({ error: 'Draw not found' });

  // Fetch all active subscribers and their scores
  const { data: participants } = await supabase
    .from('profiles')
    .select('id, full_name, golf_scores(score)')
    .not('subscriptions', 'is', null);

  const formatted = (participants || []).map(p => ({
    user_id: p.id,
    full_name: p.full_name,
    scores: (p.golf_scores || []).map(s => s.score)
  })).filter(p => p.scores.length > 0);

  const result = runDraw({
    logic: logic || draw.logic,
    participants: formatted,
    totalPool: draw.total_pool,
    rolloverAmount: draw.rollover_amount
  });

  res.json({ simulation: true, ...result });
});

/**
 * POST /api/draws/:id/publish (Admin)
 * Run official draw and publish results
 */
router.post('/:id/publish', requireAuth, requireAdmin, async (req, res) => {
  const { data: draw } = await supabase
    .from('draws')
    .select('*')
    .eq('id', req.params.id)
    .single();

  if (!draw) return res.status(404).json({ error: 'Draw not found' });
  if (draw.status === 'published') {
    return res.status(400).json({ error: 'Draw already published' });
  }

  // Fetch participants with their scores
  const { data: subs } = await supabase
    .from('subscriptions')
    .select('user_id')
    .eq('status', 'active');

  const userIds = (subs || []).map(s => s.user_id);

  const { data: scores } = await supabase
    .from('golf_scores')
    .select('user_id, score')
    .in('user_id', userIds);

  // Group scores by user
  const scoreMap = {};
  for (const s of scores || []) {
    if (!scoreMap[s.user_id]) scoreMap[s.user_id] = [];
    scoreMap[s.user_id].push(s.score);
  }

  const participants = userIds
    .filter(uid => (scoreMap[uid] || []).length > 0)
    .map(uid => ({ user_id: uid, scores: scoreMap[uid] }));

  const result = runDraw({
    logic: draw.logic,
    participants,
    totalPool: draw.total_pool,
    rolloverAmount: draw.rollover_amount
  });

  // Save draw results
  await supabase.from('draws').update({
    status: 'published',
    drawn_numbers: result.drawnNumbers,
    pool_match5: result.pools.match5,
    pool_match4: result.pools.match4,
    pool_match3: result.pools.match3,
    jackpot_rolled_over: result.jackpotRolledOver,
    rollover_amount: result.rolloverAmount,
    published_at: new Date().toISOString()
  }).eq('id', req.params.id);

  // Save all participants
  const participantRows = result.participants.map(p => ({
    draw_id: req.params.id,
    user_id: p.user_id,
    scores: p.scores,
    matched_count: p.matched,
    tier: p.tier
  }));
  await supabase.from('draw_participants').insert(participantRows);

  // Save winners
  const winnerRows = [
    ...result.winners.match5.map(w => ({ draw_id: req.params.id, user_id: w.user_id, tier: 'match_5', prize_amount: result.prizes.match5 })),
    ...result.winners.match4.map(w => ({ draw_id: req.params.id, user_id: w.user_id, tier: 'match_4', prize_amount: result.prizes.match4 })),
    ...result.winners.match3.map(w => ({ draw_id: req.params.id, user_id: w.user_id, tier: 'match_3', prize_amount: result.prizes.match3 }))
  ];
  if (winnerRows.length > 0) {
    await supabase.from('winners').insert(winnerRows);
  }

  res.json({ published: true, draw_id: req.params.id, ...result });
});

module.exports = router;
