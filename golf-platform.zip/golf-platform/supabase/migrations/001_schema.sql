-- ============================================================
-- Golf Charity Subscription Platform — Database Schema
-- Migration 001: Core Tables
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE subscription_plan AS ENUM ('monthly', 'yearly');
CREATE TYPE subscription_status AS ENUM ('active', 'inactive', 'cancelled', 'lapsed');
CREATE TYPE draw_status AS ENUM ('draft', 'simulation', 'published');
CREATE TYPE draw_logic AS ENUM ('random', 'algorithmic');
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'rejected');
CREATE TYPE winner_tier AS ENUM ('match_5', 'match_4', 'match_3');

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================

CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  country TEXT DEFAULT 'IE',
  is_admin BOOLEAN DEFAULT FALSE,
  charity_id UUID, -- FK added after charities table
  charity_percentage NUMERIC(5,2) DEFAULT 10.00 CHECK (charity_percentage >= 10 AND charity_percentage <= 100),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SUBSCRIPTIONS
-- ============================================================

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  plan subscription_plan NOT NULL,
  status subscription_status NOT NULL DEFAULT 'active',
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT UNIQUE,
  amount_paid NUMERIC(10,2) NOT NULL, -- in user's currency
  currency TEXT DEFAULT 'EUR',
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- GOLF SCORES
-- ============================================================

CREATE TABLE golf_scores (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  score INTEGER NOT NULL CHECK (score >= 1 AND score <= 45),
  played_date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for efficient per-user latest scores fetch
CREATE INDEX idx_golf_scores_user_date ON golf_scores(user_id, played_date DESC);

-- ============================================================
-- CHARITIES
-- ============================================================

CREATE TABLE charities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  logo_url TEXT,
  banner_url TEXT,
  website_url TEXT,
  is_featured BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  total_raised NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Charity events (e.g. upcoming golf days)
CREATE TABLE charity_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  charity_id UUID NOT NULL REFERENCES charities(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  event_date DATE NOT NULL,
  location TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add FK on profiles
ALTER TABLE profiles ADD CONSTRAINT fk_profiles_charity
  FOREIGN KEY (charity_id) REFERENCES charities(id) ON DELETE SET NULL;

-- ============================================================
-- DRAWS
-- ============================================================

CREATE TABLE draws (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  month INTEGER NOT NULL CHECK (month >= 1 AND month <= 12),
  year INTEGER NOT NULL,
  logic draw_logic NOT NULL DEFAULT 'random',
  status draw_status NOT NULL DEFAULT 'draft',
  drawn_numbers INTEGER[] NOT NULL DEFAULT '{}', -- 5 numbers drawn
  jackpot_rolled_over BOOLEAN DEFAULT FALSE,
  rollover_amount NUMERIC(12,2) DEFAULT 0,
  total_pool NUMERIC(12,2) DEFAULT 0,
  pool_match5 NUMERIC(12,2) DEFAULT 0,
  pool_match4 NUMERIC(12,2) DEFAULT 0,
  pool_match3 NUMERIC(12,2) DEFAULT 0,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(month, year)
);

-- Draw participants snapshot (users + their scores at time of draw)
CREATE TABLE draw_participants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  draw_id UUID NOT NULL REFERENCES draws(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  scores INTEGER[] NOT NULL, -- snapshot of user's 5 scores at draw time
  matched_count INTEGER DEFAULT 0,
  tier winner_tier,
  UNIQUE(draw_id, user_id)
);

-- ============================================================
-- WINNERS
-- ============================================================

CREATE TABLE winners (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  draw_id UUID NOT NULL REFERENCES draws(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tier winner_tier NOT NULL,
  prize_amount NUMERIC(12,2),
  proof_url TEXT,
  payment_status payment_status DEFAULT 'pending',
  verified_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- CHARITY CONTRIBUTIONS LOG
-- ============================================================

CREATE TABLE charity_contributions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  charity_id UUID NOT NULL REFERENCES charities(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
  amount NUMERIC(10,2) NOT NULL,
  percentage NUMERIC(5,2) NOT NULL,
  period_month INTEGER,
  period_year INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- UPDATED_AT TRIGGER FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_charities_updated_at
  BEFORE UPDATE ON charities
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_draws_updated_at
  BEFORE UPDATE ON draws
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_winners_updated_at
  BEFORE UPDATE ON winners
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- ROLLING 5-SCORE ENFORCEMENT (trigger)
-- ============================================================

CREATE OR REPLACE FUNCTION enforce_rolling_5_scores()
RETURNS TRIGGER AS $$
DECLARE
  score_count INTEGER;
  oldest_id UUID;
BEGIN
  SELECT COUNT(*) INTO score_count
  FROM golf_scores WHERE user_id = NEW.user_id;

  IF score_count >= 5 THEN
    SELECT id INTO oldest_id
    FROM golf_scores
    WHERE user_id = NEW.user_id
    ORDER BY played_date ASC, created_at ASC
    LIMIT 1;

    DELETE FROM golf_scores WHERE id = oldest_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_rolling_scores
  BEFORE INSERT ON golf_scores
  FOR EACH ROW EXECUTE FUNCTION enforce_rolling_5_scores();
