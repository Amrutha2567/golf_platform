-- ============================================================
-- Migration 002: Row Level Security Policies
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE golf_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE charities ENABLE ROW LEVEL SECURITY;
ALTER TABLE charity_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE draws ENABLE ROW LEVEL SECURITY;
ALTER TABLE draw_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE winners ENABLE ROW LEVEL SECURITY;
ALTER TABLE charity_contributions ENABLE ROW LEVEL SECURITY;

-- Helper: check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
  SELECT COALESCE(
    (SELECT is_admin FROM profiles WHERE id = auth.uid()),
    FALSE
  );
$$ LANGUAGE SQL SECURITY DEFINER;

-- ============================================================
-- PROFILES
-- ============================================================

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT USING (is_admin());

CREATE POLICY "Admins can update all profiles"
  ON profiles FOR UPDATE USING (is_admin());

-- ============================================================
-- SUBSCRIPTIONS
-- ============================================================

CREATE POLICY "Users can view own subscription"
  ON subscriptions FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all subscriptions"
  ON subscriptions FOR SELECT USING (is_admin());

CREATE POLICY "Admins can manage subscriptions"
  ON subscriptions FOR ALL USING (is_admin());

-- ============================================================
-- GOLF SCORES
-- ============================================================

CREATE POLICY "Users can manage own scores"
  ON golf_scores FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all scores"
  ON golf_scores FOR ALL USING (is_admin());

-- ============================================================
-- CHARITIES — public read, admin write
-- ============================================================

CREATE POLICY "Public can view active charities"
  ON charities FOR SELECT USING (is_active = TRUE);

CREATE POLICY "Admins can manage charities"
  ON charities FOR ALL USING (is_admin());

CREATE POLICY "Public can view charity events"
  ON charity_events FOR SELECT USING (TRUE);

CREATE POLICY "Admins can manage charity events"
  ON charity_events FOR ALL USING (is_admin());

-- ============================================================
-- DRAWS — published draws are public, admin manages all
-- ============================================================

CREATE POLICY "Public can view published draws"
  ON draws FOR SELECT USING (status = 'published');

CREATE POLICY "Admins can manage draws"
  ON draws FOR ALL USING (is_admin());

-- ============================================================
-- DRAW PARTICIPANTS
-- ============================================================

CREATE POLICY "Users can view own participation"
  ON draw_participants FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage draw participants"
  ON draw_participants FOR ALL USING (is_admin());

-- ============================================================
-- WINNERS
-- ============================================================

CREATE POLICY "Users can view own winnings"
  ON winners FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can upload proof"
  ON winners FOR UPDATE USING (
    auth.uid() = user_id AND payment_status = 'pending'
  );

CREATE POLICY "Admins can manage winners"
  ON winners FOR ALL USING (is_admin());

-- ============================================================
-- CHARITY CONTRIBUTIONS
-- ============================================================

CREATE POLICY "Users can view own contributions"
  ON charity_contributions FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all contributions"
  ON charity_contributions FOR SELECT USING (is_admin());
