-- ============================================================
-- Migration 003: Seed Charities
-- ============================================================

INSERT INTO charities (name, slug, description, website_url, is_featured, is_active) VALUES
(
  'Irish Cancer Society',
  'irish-cancer-society',
  'Funding research and supporting those affected by cancer across Ireland.',
  'https://www.cancer.ie',
  TRUE, TRUE
),
(
  'Barnardos Ireland',
  'barnardos-ireland',
  'Supporting vulnerable children and families throughout Ireland.',
  'https://www.barnardos.ie',
  FALSE, TRUE
),
(
  'Dogs Trust Ireland',
  'dogs-trust-ireland',
  'Rescuing and rehoming dogs while promoting responsible ownership.',
  'https://www.dogstrust.ie',
  FALSE, TRUE
),
(
  'Trócaire',
  'trocaire',
  'Working with communities in the developing world to tackle poverty.',
  'https://www.trocaire.org',
  FALSE, TRUE
),
(
  'St. Vincent de Paul',
  'st-vincent-de-paul',
  'Providing practical assistance to people in need across Ireland.',
  'https://www.svp.ie',
  FALSE, TRUE
),
(
  'Golf Foundation',
  'golf-foundation',
  'Making golf accessible to young people and communities across the UK and Ireland.',
  'https://www.golf-foundation.org',
  TRUE, TRUE
);

-- Seed admin user profile (update UUID after creating via Supabase Auth)
-- INSERT INTO profiles (id, email, full_name, is_admin)
-- VALUES ('REPLACE_WITH_AUTH_USER_UUID', 'admin@golfcharity.com', 'Platform Admin', TRUE);
