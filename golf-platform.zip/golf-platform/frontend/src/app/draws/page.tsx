import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Trophy, Calendar, TrendingUp } from 'lucide-react';
import type { Draw } from '@/lib/types';
import { MONTH_NAMES } from '@/lib/types';

async function getDraws(): Promise<Draw[]> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/draws`, { cache: 'no-store' });
    return res.ok ? res.json() : [];
  } catch {
    return [];
  }
}

export default async function DrawsPage() {
  const draws = await getDraws();

  return (
    <>
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">

        <div className="text-center mb-12">
          <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">Monthly draws</p>
          <h1 className="section-title mb-4">Draw Results</h1>
          <p className="text-muted text-sm max-w-md mx-auto">Published draw results and prize pool breakdowns. Numbers drawn once per month.</p>
        </div>

        {draws.length === 0 ? (
          <div className="text-center py-20 text-muted">
            <Trophy className="w-8 h-8 mx-auto mb-3 opacity-30" />
            <p>No draws published yet. The first draw is coming soon!</p>
          </div>
        ) : (
          <div className="space-y-5">
            {draws.map((draw, idx) => (
              <DrawCard key={draw.id} draw={draw} isLatest={idx === 0} />
            ))}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}

function DrawCard({ draw, isLatest }: { draw: Draw; isLatest: boolean }) {
  return (
    <div className={`card ${isLatest ? 'border-green-400/30 shadow-[0_0_30px_rgba(34,197,94,0.08)]' : ''}`}>
      <div className="flex items-start justify-between mb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="font-display text-xl font-bold">
              {MONTH_NAMES[draw.month - 1]} {draw.year}
            </h2>
            {isLatest && <span className="badge-green">Latest</span>}
            {draw.jackpot_rolled_over && <span className="badge-yellow">Jackpot Rolled Over</span>}
          </div>
          <p className="text-xs text-muted flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Published {draw.published_at ? new Date(draw.published_at).toLocaleDateString('en-IE', { day: 'numeric', month: 'long', year: 'numeric' }) : 'N/A'}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted mb-0.5">Total pool</p>
          <p className="font-display text-2xl font-bold text-green-400">€{draw.total_pool.toLocaleString()}</p>
        </div>
      </div>

      {/* Drawn numbers */}
      {draw.drawn_numbers.length > 0 && (
        <div className="mb-5">
          <p className="text-xs text-muted uppercase tracking-widest mb-3">Drawn Numbers</p>
          <div className="flex items-center gap-3 flex-wrap">
            {draw.drawn_numbers.map((num, i) => (
              <div
                key={i}
                className="w-12 h-12 rounded-full border-2 border-green-400/60 bg-green-400/10 flex items-center justify-center font-display text-lg font-bold text-green-300 shadow-[0_0_12px_rgba(34,197,94,0.2)]"
              >
                {num}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Prize pools */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: '5-Match 🏆', amount: draw.pool_match5, color: 'text-yellow-400', bg: 'bg-yellow-400/8 border-yellow-400/20' },
          { label: '4-Match 🥈', amount: draw.pool_match4, color: 'text-blue-400',   bg: 'bg-blue-400/8 border-blue-400/20' },
          { label: '3-Match 🥉', amount: draw.pool_match3, color: 'text-green-400',  bg: 'bg-green-400/8 border-green-400/20' },
        ].map(tier => (
          <div key={tier.label} className={`rounded-xl border p-3 text-center ${tier.bg}`}>
            <p className="text-xs text-muted mb-1">{tier.label}</p>
            <p className={`font-display text-lg font-bold ${tier.color}`}>€{tier.amount.toLocaleString()}</p>
          </div>
        ))}
      </div>

      {draw.jackpot_rolled_over && (
        <div className="mt-4 flex items-center gap-2 p-3 rounded-lg bg-yellow-400/5 border border-yellow-400/15">
          <TrendingUp className="w-4 h-4 text-yellow-400 flex-shrink-0" />
          <p className="text-xs text-yellow-400/80">
            No 5-match winner this month. €{draw.rollover_amount.toLocaleString()} jackpot rolls over to next draw.
          </p>
        </div>
      )}
    </div>
  );
}
