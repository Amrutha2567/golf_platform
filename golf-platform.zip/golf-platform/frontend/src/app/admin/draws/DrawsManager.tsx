'use client';

import { useState } from 'react';
import { Plus, Play, Send, Loader2, BarChart2, Calendar } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { apiFetch } from '@/lib/api';
import { MONTH_NAMES, type Draw } from '@/lib/types';
import toast from 'react-hot-toast';

export default function DrawsManager({ initialDraws }: { initialDraws: Draw[] }) {
  const supabase = createClient();
  const [draws, setDraws] = useState<Draw[]>(initialDraws);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [simResult, setSimResult] = useState<any | null>(null);

  // New draw form
  const [showForm, setShowForm] = useState(false);
  const [formMonth, setFormMonth] = useState(String(new Date().getMonth() + 1));
  const [formYear,  setFormYear]  = useState(String(new Date().getFullYear()));
  const [formLogic, setFormLogic] = useState<'random' | 'algorithmic'>('random');
  const [creating,  setCreating]  = useState(false);

  const getToken = async () => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token || '';
  };

  const handleCreate = async () => {
    setCreating(true);
    try {
      const token = await getToken();
      const data = await apiFetch<Draw>('/api/admin/draws', {
        method: 'POST',
        token,
        body: JSON.stringify({ month: parseInt(formMonth), year: parseInt(formYear), logic: formLogic }),
      });
      setDraws(prev => [data, ...prev]);
      setShowForm(false);
      toast.success('Draw created!');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleSimulate = async (drawId: string, logic: string) => {
    setLoadingId(drawId + '-sim');
    setSimResult(null);
    try {
      const token = await getToken();
      const result = await apiFetch<any>('/api/draws/simulate', {
        method: 'POST',
        token,
        body: JSON.stringify({ draw_id: drawId, logic }),
      });
      setSimResult({ drawId, ...result });
      toast.success('Simulation complete!');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingId(null);
    }
  };

  const handlePublish = async (drawId: string) => {
    if (!confirm('Publish this draw? This will finalise results and notify winners.')) return;
    setLoadingId(drawId + '-pub');
    try {
      const token = await getToken();
      await apiFetch(`/api/draws/${drawId}/publish`, { method: 'POST', token });
      setDraws(prev => prev.map(d => d.id === drawId ? { ...d, status: 'published' } : d));
      toast.success('Draw published!');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div>
      {/* Header action */}
      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-muted">{draws.length} draw(s) total</p>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary py-2 text-sm">
          <Plus className="w-4 h-4" /> New Draw
        </button>
      </div>

      {/* Create form */}
      {showForm && (
        <div className="card mb-6 space-y-4">
          <h3 className="font-semibold text-sm">Create New Draw</h3>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-muted block mb-1">Month</label>
              <select value={formMonth} onChange={e => setFormMonth(e.target.value)} className="input-field text-sm">
                {MONTH_NAMES.map((m, i) => (
                  <option key={i} value={i + 1}>{m}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Year</label>
              <input type="number" value={formYear} onChange={e => setFormYear(e.target.value)} className="input-field text-sm" min={2024} max={2030} />
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Logic</label>
              <select value={formLogic} onChange={e => setFormLogic(e.target.value as any)} className="input-field text-sm">
                <option value="random">Random</option>
                <option value="algorithmic">Algorithmic</option>
              </select>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={handleCreate} disabled={creating} className="btn-primary py-2 text-sm disabled:opacity-50">
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Draw'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-outline py-2 text-sm">Cancel</button>
          </div>
        </div>
      )}

      {/* Simulation result */}
      {simResult && (
        <div className="card mb-6 border-blue-400/30">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-blue-400 flex items-center gap-2">
              <BarChart2 className="w-4 h-4" /> Simulation Result
            </h3>
            <button onClick={() => setSimResult(null)} className="text-xs text-muted hover:text-white/70 transition-colors">Dismiss</button>
          </div>
          <div className="flex items-center gap-3 mb-3 flex-wrap">
            <span className="text-xs text-muted">Drawn:</span>
            {(simResult.drawnNumbers || []).map((n: number, i: number) => (
              <span key={i} className="w-8 h-8 rounded-full bg-blue-400/15 border border-blue-400/30 flex items-center justify-center text-xs font-bold text-blue-300">
                {n}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3 text-xs">
            {[
              { label: '5-Match', count: simResult.winners?.match5?.length || 0, prize: simResult.prizes?.match5 },
              { label: '4-Match', count: simResult.winners?.match4?.length || 0, prize: simResult.prizes?.match4 },
              { label: '3-Match', count: simResult.winners?.match3?.length || 0, prize: simResult.prizes?.match3 },
            ].map(t => (
              <div key={t.label} className="bg-white/4 rounded-lg p-2 text-center">
                <p className="text-muted">{t.label}</p>
                <p className="font-bold mt-0.5">{t.count} winner(s)</p>
                {t.prize > 0 && <p className="text-green-400">€{t.prize} each</p>}
              </div>
            ))}
          </div>
          {simResult.jackpotRolledOver && (
            <p className="text-xs text-yellow-400/80 mt-3">⚠ Jackpot would roll over (no 5-match winners)</p>
          )}
        </div>
      )}

      {/* Draw list */}
      {draws.length === 0 ? (
        <div className="text-center py-16 text-muted">
          <Calendar className="w-8 h-8 mx-auto mb-3 opacity-30" />
          <p>No draws yet. Create the first one!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {draws.map(draw => (
            <div key={draw.id} className="card">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="font-semibold">{MONTH_NAMES[draw.month - 1]} {draw.year}</h3>
                    <span className={`badge text-xs ${
                      draw.status === 'published' ? 'badge-green' :
                      draw.status === 'simulation' ? 'badge-blue' : 'badge-yellow'
                    }`}>{draw.status}</span>
                    <span className="text-xs text-muted capitalize">{draw.logic}</span>
                  </div>
                  <p className="text-sm text-green-400 font-semibold">Pool: €{draw.total_pool.toLocaleString()}</p>
                  {draw.drawn_numbers.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-2">
                      {draw.drawn_numbers.map((n, i) => (
                        <span key={i} className="w-7 h-7 rounded-full bg-green-400/15 border border-green-400/30 flex items-center justify-center text-xs font-bold text-green-300">
                          {n}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {draw.status !== 'published' && (
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => handleSimulate(draw.id, draw.logic)}
                      disabled={loadingId === draw.id + '-sim'}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-400/10 border border-blue-400/20 text-blue-400 hover:bg-blue-400/20 transition-colors disabled:opacity-50"
                    >
                      {loadingId === draw.id + '-sim' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                      Simulate
                    </button>
                    <button
                      onClick={() => handlePublish(draw.id)}
                      disabled={loadingId === draw.id + '-pub'}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-green-400/10 border border-green-400/20 text-green-400 hover:bg-green-400/20 transition-colors disabled:opacity-50"
                    >
                      {loadingId === draw.id + '-pub' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      Publish
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
