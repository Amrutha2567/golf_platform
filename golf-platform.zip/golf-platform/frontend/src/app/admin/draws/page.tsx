import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Navbar from '@/components/layout/Navbar';
import DrawsManager from './DrawsManager';

export default async function AdminDrawsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('is_admin').eq('id', user.id).single();
  if (!profile?.is_admin) redirect('/dashboard');

  const { data: draws } = await supabase
    .from('draws')
    .select('*')
    .order('year', { ascending: false })
    .order('month', { ascending: false });

  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold mb-1">Draw Management</h1>
          <p className="text-sm text-muted">Create draws, run simulations, and publish results.</p>
        </div>
        <DrawsManager initialDraws={draws || []} />
      </main>
    </>
  );
}
