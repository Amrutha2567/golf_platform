import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Navbar from '@/components/layout/Navbar';
import { Users, CheckCircle, XCircle } from 'lucide-react';

export default async function AdminUsersPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('is_admin').eq('id', user.id).single();
  if (!profile?.is_admin) redirect('/dashboard');

  const { data: users } = await supabase
    .from('profiles')
    .select('*, subscriptions(status, plan), charities(name)')
    .order('created_at', { ascending: false })
    .limit(50);

  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold mb-1">Users</h1>
          <p className="text-sm text-muted">{users?.length || 0} registered users</p>
        </div>

        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/8">
                {['Name', 'Email', 'Subscription', 'Plan', 'Charity', 'Admin', 'Joined'].map(h => (
                  <th key={h} className="text-left text-xs text-muted uppercase tracking-wider pb-3 pr-4 font-medium whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {(users || []).map(u => {
                const sub = (u.subscriptions as any)?.[0];
                return (
                  <tr key={u.id} className="hover:bg-white/2 transition-colors">
                    <td className="py-3 pr-4 font-medium whitespace-nowrap">{u.full_name || '—'}</td>
                    <td className="py-3 pr-4 text-muted">{u.email}</td>
                    <td className="py-3 pr-4">
                      {sub ? (
                        <span className={`badge text-xs ${sub.status === 'active' ? 'badge-green' : 'badge-red'}`}>{sub.status}</span>
                      ) : (
                        <span className="text-muted text-xs">None</span>
                      )}
                    </td>
                    <td className="py-3 pr-4 text-muted capitalize">{sub?.plan || '—'}</td>
                    <td className="py-3 pr-4 text-muted">{(u.charities as any)?.name || '—'}</td>
                    <td className="py-3 pr-4">
                      {u.is_admin
                        ? <CheckCircle className="w-4 h-4 text-green-400" />
                        : <XCircle className="w-4 h-4 text-white/20" />
                      }
                    </td>
                    <td className="py-3 text-muted text-xs whitespace-nowrap">
                      {new Date(u.created_at).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {(users || []).length === 0 && (
            <div className="text-center py-12 text-muted">
              <Users className="w-7 h-7 mx-auto mb-2 opacity-30" />
              <p>No users yet.</p>
            </div>
          )}
        </div>
      </main>
    </>
  );
}
