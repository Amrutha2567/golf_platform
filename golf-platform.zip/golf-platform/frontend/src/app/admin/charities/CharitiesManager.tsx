'use client';

import { useState } from 'react';
import { Plus, Edit2, Trash2, Star, ExternalLink, Loader2, Check, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { apiFetch } from '@/lib/api';
import type { Charity } from '@/lib/types';
import toast from 'react-hot-toast';

const BLANK = { name: '', slug: '', description: '', website_url: '', logo_url: '', is_featured: false };

export default function CharitiesManager({ initialCharities }: { initialCharities: Charity[] }) {
  const supabase = createClient();
  const [charities, setCharities] = useState<Charity[]>(initialCharities);
  const [showForm, setShowForm]   = useState(false);
  const [editId,   setEditId]     = useState<string | null>(null);
  const [form,     setForm]       = useState(BLANK);
  const [saving,   setSaving]     = useState(false);
  const [deleting, setDeleting]   = useState<string | null>(null);

  const getToken = async () => {
    const { data } = await supabase.auth.getSession();
    return data.session?.access_token || '';
  };

  const slugify = (s: string) =>
    s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  const handleNameChange = (val: string) => {
    setForm(prev => ({ ...prev, name: val, slug: editId ? prev.slug : slugify(val) }));
  };

  const handleSave = async () => {
    if (!form.name || !form.slug) {
      toast.error('Name and slug are required');
      return;
    }
    setSaving(true);
    try {
      const token = await getToken();
      if (editId) {
        const updated = await apiFetch<Charity>(`/api/charities/${editId}`, {
          method: 'PUT', token, body: JSON.stringify(form)
        });
        setCharities(prev => prev.map(c => c.id === editId ? { ...c, ...updated } : c));
        toast.success('Charity updated');
      } else {
        const created = await apiFetch<Charity>('/api/charities', {
          method: 'POST', token, body: JSON.stringify(form)
        });
        setCharities(prev => [created, ...prev]);
        toast.success('Charity created!');
      }
      setShowForm(false);
      setEditId(null);
      setForm(BLANK);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (c: Charity) => {
    setEditId(c.id);
    setForm({ name: c.name, slug: c.slug, description: c.description || '', website_url: c.website_url || '', logo_url: c.logo_url || '', is_featured: c.is_featured });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deactivate this charity?')) return;
    setDeleting(id);
    try {
      const token = await getToken();
      await apiFetch(`/api/charities/${id}`, { method: 'DELETE', token });
      setCharities(prev => prev.map(c => c.id === id ? { ...c, is_active: false } : c));
      toast.success('Charity deactivated');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setDeleting(null);
    }
  };

  const cancel = () => { setShowForm(false); setEditId(null); setForm(BLANK); };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-muted">{charities.length} charities</p>
        <button onClick={() => { cancel(); setShowForm(true); }} className="btn-primary py-2 text-sm">
          <Plus className="w-4 h-4" /> Add Charity
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card mb-6 space-y-4">
          <h3 className="font-semibold text-sm">{editId ? 'Edit Charity' : 'New Charity'}</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted block mb-1">Name *</label>
              <input value={form.name} onChange={e => handleNameChange(e.target.value)} className="input-field text-sm" placeholder="Irish Cancer Society" />
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Slug *</label>
              <input value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="input-field text-sm" placeholder="irish-cancer-society" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs text-muted block mb-1">Description</label>
              <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={2} className="input-field text-sm resize-none" />
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Website URL</label>
              <input value={form.website_url} onChange={e => setForm(p => ({ ...p, website_url: e.target.value }))} className="input-field text-sm" placeholder="https://..." />
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Logo URL</label>
              <input value={form.logo_url} onChange={e => setForm(p => ({ ...p, logo_url: e.target.value }))} className="input-field text-sm" placeholder="https://..." />
            </div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <div
              onClick={() => setForm(p => ({ ...p, is_featured: !p.is_featured }))}
              className={`w-9 h-5 rounded-full relative transition-colors ${form.is_featured ? 'bg-green-400' : 'bg-white/15'}`}
            >
              <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form.is_featured ? 'translate-x-4' : 'translate-x-0.5'}`} />
            </div>
            <span className="text-sm text-muted">Featured charity</span>
          </label>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={saving} className="btn-primary py-2 text-sm disabled:opacity-50">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Check className="w-4 h-4" />{editId ? 'Update' : 'Create'}</>}
            </button>
            <button onClick={cancel} className="btn-outline py-2 text-sm"><X className="w-4 h-4" /> Cancel</button>
          </div>
        </div>
      )}

      {/* Charity list */}
      <div className="space-y-3">
        {charities.map(c => (
          <div key={c.id} className={`card flex items-center gap-4 ${!c.is_active ? 'opacity-40' : ''}`}>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-sm">{c.name}</span>
                {c.is_featured && <Star className="w-3.5 h-3.5 text-yellow-400" fill="currentColor" />}
                {!c.is_active && <span className="badge-red text-xs">Inactive</span>}
              </div>
              <p className="text-xs text-muted">{c.slug}</p>
              {c.total_raised > 0 && <p className="text-xs text-green-400 mt-0.5">€{c.total_raised.toLocaleString()} raised</p>}
            </div>
            {c.website_url && (
              <a href={c.website_url} target="_blank" rel="noopener noreferrer" className="text-white/30 hover:text-white/60 transition-colors">
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
            <button onClick={() => handleEdit(c)} className="p-2 rounded-lg hover:bg-white/8 text-white/40 hover:text-white/70 transition-colors">
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleDelete(c.id)}
              disabled={deleting === c.id || !c.is_active}
              className="p-2 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 transition-colors disabled:opacity-30"
            >
              {deleting === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
