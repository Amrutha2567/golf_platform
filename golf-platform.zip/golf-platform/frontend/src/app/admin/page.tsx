import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Navbar from '@/components/layout/Navbar';
import { Users, CreditCard, Trophy, Heart, BarChart3, ShieldCheck } from 'lucide-react';
import Link from 'next/link';

export default async function AdminPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('is_admin').eq('id', user.id).single();
  if (!profile?.is_admin) redirect('/dashboard');

  // Fetch basic stats
  const [
    { count: totalUsers },
    { count: activeSubs },
    { data: winners },
    { data: contributions },
  ] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('subscriptions').select('*', { count: 'exact', head: true }).eq('status', 'active'),
    supabase.from('winners').select('prize_amount'),
    supabase.from('charity_contributions').select('amount'),
  ]);

  const totalPrizes = (winners || []).reduce((s, w) => s + (w.prize_amount || 0), 0);
  const totalCharity = (contributions || []).reduce((s, c) => s + (c.amount || 0), 0);

  const stats = [
    { icon: Users,      label: 'Total Users',    value: totalUsers || 0,           color: 'text-blue-400',   bg: 'bg-blue-400/10 border-blue-400/20' },
    { icon: CreditCard, label: 'Active Subs',    value: activeSubs || 0,           color: 'text-green-400',  bg: 'bg-green-400/10 border-green-400/20' },
    { icon: Trophy,     label: 'Prizes Paid',    value: `€${totalPrizes.toFixed(0)}`, color: 'text-yellow-400', bg: 'bg-yellow-400/10 border-yellow-400/20' },
    { icon: Heart,      label: 'Charity Raised', value: `€${totalCharity.toFixed(0)}`, color: 'text-pink-400',   bg: 'bg-pink-400/10 border-pink-400/20' },
  ];

  const adminLinks = [
    { href: '/admin/users',    icon: Users,      label: 'Users',      desc: 'View, edit users and subscriptions' },
    { href: '/admin/draws',    icon: BarChart3,  label: 'Draws',      desc: 'Configure, simulate, publish draws' },
    { href: '/admin/winners',  icon: Trophy,     label: 'Winners',    desc: 'Verify proofs and mark payouts' },
    { href: '/admin/charities',icon: Heart,      label: 'Charities',  desc: 'Manage charity listings and events' },
  ];

  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">

        <div className="flex items-center gap-3 mb-8">
          <div className="w-9 h-9 rounded-xl bg-green-400/15 border border-green-400/25 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4 text-green-400" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold">Admin Dashboard</h1>
            <p className="text-xs text-muted">Full platform control</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(s => (
            <div key={s.label} className="card">
              <div className={`w-9 h-9 rounded-xl border flex items-center justify-center mb-3 ${s.bg}`}>
                <s.icon className={`w-4 h-4 ${s.color}`} />
              </div>
              <p className="font-display text-2xl font-bold">{s.value}</p>
              <p className="text-xs text-muted mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Nav links */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {adminLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              className="card hover:border-green-400/30 transition-all duration-300 group"
            >
              <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4 group-hover:border-green-400/30 group-hover:bg-green-400/8 transition-all">
                <link.icon className="w-5 h-5 text-white/40 group-hover:text-green-400 transition-colors" />
              </div>
              <h3 className="font-semibold text-sm mb-1">{link.label}</h3>
              <p className="text-xs text-muted leading-relaxed">{link.desc}</p>
            </Link>
          ))}
        </div>
      </main>
    </>
  );
}
