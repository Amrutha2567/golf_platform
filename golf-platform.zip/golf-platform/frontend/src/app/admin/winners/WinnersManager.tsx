'use client';

import { useState } from 'react';
import { CheckCircle, XCircle, Trophy, Loader2, ExternalLink } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { apiFetch } from '@/lib/api';
import { MONTH_NAMES, TIER_LABELS, type Winner } from '@/lib/types';
import toast from 'react-hot-toast';

export default function WinnersManager({ initialWinners }: { initialWinners: Winner[] }) {
  const supabase = createClient();
  const [winners, setWinners] = useState<Winner[]>(initialWinners);
  const [filter, setFilter] = useState<'all' | 'pending' | 'paid' | 'rejected'>('all');
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});

  const handleVerify = async (id: string, approved: boolean) => {
    setLoadingId(id);
    try {
      const { data: session } = await supabase.auth.getSession();
      const token = session.session?.access_token;
      await apiFetch(`/api/admin/winners/${id}/verify`, {
        method: 'PATCH',
        token,
        body: JSON.stringify({ approved, admin_notes: notes[id] || '' }),
      });
      toast.success(approved ? 'Winner approved & paid!' : 'Submission rejected');
      setWinners(prev =>
        prev.map(w => w.id === id
          ? { ...w, payment_status: approved ? 'paid' : 'rejected' }
          : w
        )
      );
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoadingId(null);
    }
  };

  const filtered = filter === 'all' ? winners : winners.filter(w => w.payment_status === filter);

  const counts = {
    all: winners.length,
    pending: winners.filter(w => w.payment_status === 'pending').length,
    paid: winners.filter(w => w.payment_status === 'paid').length,
    rejected: winners.filter(w => w.payment_status === 'rejected').length,
  };

  return (
    <div>
      {/* Filter tabs */}
      <div className="flex items-center gap-2 mb-6 flex-wrap">
        {(['all', 'pending', 'paid', 'rejected'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors capitalize ${
              filter === f
                ? 'bg-green-400/15 text-green-400 border border-green-400/30'
                : 'text-white/40 hover:text-white/70 border border-white/10'
            }`}
          >
            {f} <span className="ml-1 text-xs opacity-70">({counts[f]})</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 text-muted">
          <Trophy className="w-8 h-8 mx-auto mb-3 opacity-30" />
          <p>No winners in this category.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(winner => {
            const profile = (winner as any).profiles;
            const draw    = (winner as any).draws;

            return (
              <div key={winner.id} className="card">
                <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                  {/* Left: winner info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-semibold text-sm">{profile?.full_name || 'Unknown'}</span>
                      <span className={`badge text-xs ${
                        winner.payment_status === 'paid'     ? 'badge-green'  :
                        winner.payment_status === 'rejected' ? 'badge-red'    : 'badge-yellow'
                      }`}>
                        {winner.payment_status}
                      </span>
                      <span className="badge badge-blue text-xs">{TIER_LABELS[winner.tier]}</span>
                    </div>
                    <p className="text-xs text-muted">{profile?.email}</p>
                    {draw && (
                      <p className="text-xs text-muted mt-0.5">
                        Draw: {MONTH_NAMES[draw.month - 1]} {draw.year}
                      </p>
                    )}
                    <p className="text-base font-bold text-green-400 mt-2">
                      €{winner.prize_amount?.toFixed(2)}
                    </p>

                    {winner.proof_url && (
                      <a
                        href={winner.proof_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs text-blue-400/70 hover:text-blue-400 transition-colors mt-2"
                      >
                        <ExternalLink className="w-3 h-3" /> View proof
                      </a>
                    )}

                    {winner.admin_notes && (
                      <p className="text-xs text-white/35 italic mt-1">Note: {winner.admin_notes}</p>
                    )}
                  </div>

                  {/* Right: actions (pending only) */}
                  {winner.payment_status === 'pending' && (
                    <div className="flex flex-col gap-2 min-w-[200px]">
                      <textarea
                        placeholder="Admin notes (optional)"
                        rows={2}
                        value={notes[winner.id] || ''}
                        onChange={e => setNotes(prev => ({ ...prev, [winner.id]: e.target.value }))}
                        className="input-field text-xs resize-none"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleVerify(winner.id, true)}
                          disabled={loadingId === winner.id}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-green-400/15 border border-green-400/30 text-green-400 text-xs font-medium hover:bg-green-400/25 transition-colors disabled:opacity-50"
                        >
                          {loadingId === winner.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle className="w-3.5 h-3.5" />}
                          Approve
                        </button>
                        <button
                          onClick={() => handleVerify(winner.id, false)}
                          disabled={loadingId === winner.id}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-red-500/10 border border-red-500/25 text-red-400 text-xs font-medium hover:bg-red-500/20 transition-colors disabled:opacity-50"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Reject
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
