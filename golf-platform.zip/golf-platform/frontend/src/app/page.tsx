import Link from 'next/link';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { ArrowRight, Heart, Trophy, Target, Zap, Users, Star } from 'lucide-react';

export default function HomePage() {
  return (
    <>
      <Navbar />

      {/* ── Hero ──────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-4">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-green-500/6 blur-[120px]" />
          <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] rounded-full bg-green-400/4 blur-[80px]" />
        </div>

        {/* Floating orbs */}
        <div className="absolute top-1/3 right-1/4 w-4 h-4 rounded-full bg-green-400/40 blur-sm animate-float" style={{ animationDelay: '0s' }} />
        <div className="absolute bottom-1/3 left-1/5 w-2 h-2 rounded-full bg-green-300/50 blur-sm animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-2/3 right-1/3 w-3 h-3 rounded-full bg-green-500/30 blur-sm animate-float" style={{ animationDelay: '4s' }} />

        <div className="relative max-w-4xl mx-auto text-center page-enter">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass border border-green-400/20 text-green-400 text-xs font-medium mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            Monthly draw now open — €12,400 prize pool
          </div>

          {/* Headline */}
          <h1 className="font-display text-5xl sm:text-7xl font-bold leading-[1.05] tracking-tight mb-6">
            Golf That Gives
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-300 via-green-400 to-emerald-500">
              Back.
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-white/50 max-w-xl mx-auto leading-relaxed mb-10">
            Enter your Stableford scores, compete in monthly prize draws,
            and support a charity you believe in — all in one place.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/subscribe" className="btn-primary text-base px-8 py-4">
              Start Subscribing
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/how-it-works" className="btn-outline text-base px-8 py-4">
              How It Works
            </Link>
          </div>

          {/* Social proof */}
          <div className="flex items-center justify-center gap-6 mt-12 text-sm text-white/30">
            <span className="flex items-center gap-1.5"><Users className="w-4 h-4" /> 2,400+ members</span>
            <span className="w-px h-4 bg-white/10" />
            <span className="flex items-center gap-1.5"><Heart className="w-4 h-4 text-green-400" /> €84,000 raised</span>
            <span className="w-px h-4 bg-white/10" />
            <span className="flex items-center gap-1.5"><Trophy className="w-4 h-4" /> 36 draws completed</span>
          </div>
        </div>
      </section>

      {/* ── How It Works ──────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-14">
          <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">Simple by design</p>
          <h2 className="section-title">Three steps. One platform.</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Zap,
              step: '01',
              title: 'Subscribe',
              desc: 'Choose monthly or yearly. A portion of your subscription builds the prize pool — and funds your chosen charity.',
            },
            {
              icon: Target,
              step: '02',
              title: 'Enter Your Scores',
              desc: 'Log your latest 5 Stableford scores after each round. The platform keeps a rolling record — your entries are always ready.',
            },
            {
              icon: Trophy,
              step: '03',
              title: 'Win & Give',
              desc: "Match 3, 4, or all 5 drawn numbers to win from the monthly prize pool. Jackpots roll over if unclaimed.",
            },
          ].map((item) => (
            <div key={item.step} className="card group hover:border-green-400/30 transition-all duration-300">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-10 h-10 rounded-xl bg-green-400/10 border border-green-400/20 flex items-center justify-center flex-shrink-0 group-hover:bg-green-400/15 transition-colors">
                  <item.icon className="w-5 h-5 text-green-400" />
                </div>
                <span className="font-display text-4xl font-bold text-white/8 leading-none">{item.step}</span>
              </div>
              <h3 className="font-display text-xl font-semibold mb-2">{item.title}</h3>
              <p className="text-sm text-white/45 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Prize Pool Breakdown ──────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="card p-8 md:p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-radial from-green-500/5 via-transparent to-transparent pointer-events-none" />
          <div className="relative grid md:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">Prize Distribution</p>
              <h2 className="section-title mb-4">How the pool splits</h2>
              <p className="text-white/45 text-sm leading-relaxed mb-6">
                Every active subscription contributes to that month's prize pool. Winnings are split across three match tiers — jackpots roll over when unclaimed.
              </p>
              <Link href="/subscribe" className="btn-primary">
                Join the draw <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="space-y-4">
              {[
                { tier: '5-Number Match', pct: 40, color: 'from-yellow-400 to-amber-500', badge: '🏆 Jackpot', rollover: true },
                { tier: '4-Number Match', pct: 35, color: 'from-blue-400 to-blue-600', badge: '🥈 Runner-up', rollover: false },
                { tier: '3-Number Match', pct: 25, color: 'from-green-400 to-emerald-600', badge: '🥉 Third tier', rollover: false },
              ].map((row) => (
                <div key={row.tier} className="flex items-center gap-4">
                  <div className="w-32 text-right text-xs text-white/40 font-medium shrink-0">{row.badge}</div>
                  <div className="flex-1 h-8 rounded-full bg-white/5 overflow-hidden">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${row.color} flex items-center justify-end pr-3`}
                      style={{ width: `${row.pct}%` }}
                    >
                      <span className="text-xs font-bold text-black/80">{row.pct}%</span>
                    </div>
                  </div>
                  {row.rollover && (
                    <span className="text-xs text-yellow-400/70 font-medium shrink-0">Rolls over</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Charity CTA ───────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">More than a game</p>
          <h2 className="section-title mb-4">
            Every subscription funds<br />
            <span className="text-green-400">a cause you care about.</span>
          </h2>
          <p className="text-white/45 max-w-md mx-auto text-sm leading-relaxed mb-8">
            Choose from our curated list of charities at signup. At least 10% of your subscription goes directly to your chosen charity — you can give more if you like.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/charities" className="btn-primary px-8 py-3">
              <Heart className="w-4 h-4" /> Explore Charities
            </Link>
            <Link href="/subscribe" className="btn-outline px-8 py-3">
              Get Started
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
