import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import Navbar from '@/components/layout/Navbar';
import ScoreEntry from '@/components/dashboard/ScoreEntry';
import { Calendar, Heart, Trophy, CreditCard, ArrowUpRight } from 'lucide-react';
import type { Profile, Subscription, Winner } from '@/lib/types';
import { MONTH_NAMES, TIER_LABELS } from '@/lib/types';
import Link from 'next/link';

export default async function DashboardPage() {
  const supabase = createClient();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('*, charities(name, slug, logo_url), subscriptions(*)')
    .eq('id', user.id)
    .single();

  const sub: Subscription | undefined = profile?.subscriptions?.[0];

  const { data: winners } = await supabase
    .from('winners')
    .select('*, draws(month, year)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(5);

  const { data: participations } = await supabase
    .from('draw_participants')
    .select('id, draws(month, year, status)')
    .eq('user_id', user.id)
    .order('id', { ascending: false })
    .limit(12);

  const totalWon = (winners || []).reduce((sum, w) => sum + (w.prize_amount || 0), 0);

  const statusColor = (status: string) => {
    if (status === 'active') return 'badge-green';
    if (status === 'cancelled' || status === 'lapsed') return 'badge-red';
    return 'badge-yellow';
  };

  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">

        {/* Greeting */}
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold">
            Hey, {profile?.full_name?.split(' ')[0] || 'Golfer'} 👋
          </h1>
          <p className="text-muted text-sm mt-1">Here's your GreenHeart overview.</p>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            {
              icon: CreditCard,
              label: 'Subscription',
              value: sub?.status ? sub.status.charAt(0).toUpperCase() + sub.status.slice(1) : 'None',
              sub: sub?.current_period_end ? `Renews ${new Date(sub.current_period_end).toLocaleDateString('en-IE', { day: 'numeric', month: 'short' })}` : 'No active plan',
              color: 'text-green-400',
              badge: sub?.status ? statusColor(sub.status) : 'badge-yellow',
            },
            {
              icon: Trophy,
              label: 'Total Won',
              value: `€${totalWon.toFixed(2)}`,
              sub: `${(winners || []).length} prize(s)`,
              color: 'text-yellow-400',
            },
            {
              icon: Calendar,
              label: 'Draws Entered',
              value: String(participations?.length || 0),
              sub: 'All time',
              color: 'text-blue-400',
            },
            {
              icon: Heart,
              label: 'Charity',
              value: profile?.charities?.name || 'None selected',
              sub: `${profile?.charity_percentage || 10}% of your sub`,
              color: 'text-pink-400',
            },
          ].map((stat) => (
            <div key={stat.label} className="card">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs text-muted">{stat.label}</p>
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <p className="font-display text-xl font-bold leading-tight truncate">{stat.value}</p>
              <p className="text-xs text-muted mt-1">{stat.sub}</p>
            </div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Score entry (takes 2 cols) */}
          <div className="lg:col-span-2">
            <ScoreEntry />
          </div>

          {/* Right panel */}
          <div className="space-y-5">
            {/* Subscription card */}
            <div className="card">
              <h3 className="font-display text-base font-semibold mb-4">Subscription</h3>
              {sub ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted">Plan</span>
                    <span className="capitalize font-medium">{sub.plan}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted">Amount</span>
                    <span className="font-medium">€{sub.amount_paid}/{sub.plan === 'monthly' ? 'mo' : 'yr'}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted">Status</span>
                    <span className={`badge ${statusColor(sub.status)}`}>{sub.status}</span>
                  </div>
                  {sub.current_period_end && (
                    <div className="flex justify-between">
                      <span className="text-muted">Next billing</span>
                      <span className="font-medium">{new Date(sub.current_period_end).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-sm text-muted mb-3">No active subscription</p>
                  <Link href="/subscribe" className="btn-primary py-2 text-sm">Subscribe Now</Link>
                </div>
              )}
            </div>

            {/* Charity card */}
            <div className="card">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-display text-base font-semibold">My Charity</h3>
                <Link href="/settings" className="text-xs text-green-400/70 hover:text-green-400 transition-colors flex items-center gap-1">
                  Change <ArrowUpRight className="w-3 h-3" />
                </Link>
              </div>
              {profile?.charities ? (
                <div>
                  <p className="font-medium text-sm">{profile.charities.name}</p>
                  <p className="text-xs text-muted mt-1">
                    <span className="text-green-400 font-semibold">{profile.charity_percentage}%</span> of your subscription
                  </p>
                </div>
              ) : (
                <p className="text-sm text-muted">No charity selected yet.</p>
              )}
            </div>
          </div>
        </div>

        {/* Winnings history */}
        {(winners || []).length > 0 && (
          <div className="mt-6 card">
            <h3 className="font-display text-lg font-semibold mb-4">Winnings</h3>
            <div className="divide-y divide-white/5">
              {winners!.map(w => (
                <div key={w.id} className="flex items-center gap-4 py-3">
                  <div className="w-8 h-8 rounded-lg bg-yellow-400/10 border border-yellow-400/20 flex items-center justify-center flex-shrink-0">
                    <Trophy className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{TIER_LABELS[w.tier]}</p>
                    <p className="text-xs text-muted">
                      {MONTH_NAMES[(w.draws as any)?.month - 1]} {(w.draws as any)?.year}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-green-400">€{w.prize_amount?.toFixed(2)}</p>
                    <span className={`badge text-xs ${w.payment_status === 'paid' ? 'badge-green' : w.payment_status === 'rejected' ? 'badge-red' : 'badge-yellow'}`}>
                      {w.payment_status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </>
  );
}
