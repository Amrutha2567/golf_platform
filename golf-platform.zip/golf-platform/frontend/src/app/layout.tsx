import type { Metadata } from 'next';
import '@/styles/globals.css';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'GreenHeart — Golf & Giving',
  description: 'Subscribe. Play. Win. Give. The golf platform that does more.',
  keywords: 'golf, charity, subscription, prize draw, stableford',
  openGraph: {
    title: 'GreenHeart — Golf & Giving',
    description: 'Track your game, support a cause, win monthly prizes.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#0a0f0a] text-[#f0fdf4] font-body antialiased">
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#0f1a0f',
              color: '#f0fdf4',
              border: '1px solid rgba(34,197,94,0.2)',
              borderRadius: '12px',
            },
            success: {
              iconTheme: { primary: '#22c55e', secondary: '#0a0f0a' },
            },
          }}
        />
        {children}
      </body>
    </html>
  );
}
