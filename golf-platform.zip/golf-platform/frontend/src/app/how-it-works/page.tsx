import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import { Zap, Target, Trophy, Heart, ArrowRight, CheckCircle } from 'lucide-react';

export default function HowItWorksPage() {
  return (
    <>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">

        <div className="text-center mb-16">
          <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">Transparent & simple</p>
          <h1 className="font-display text-4xl sm:text-5xl font-bold mb-4">How GreenHeart works</h1>
          <p className="text-muted max-w-lg mx-auto leading-relaxed">
            A subscription platform built around golf, community, and charitable giving. Here's everything you need to know.
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-10 mb-20">
          {[
            {
              icon: Zap,
              step: '01',
              title: 'Subscribe to the platform',
              content: [
                'Choose a Monthly (€9.99) or Yearly (€99) subscription plan.',
                'Payment is processed securely via Stripe.',
                'A fixed percentage of your subscription contributes to that month\'s prize pool.',
                'The remaining portion (minimum 10%) is directed to your chosen charity.',
                'Non-subscribers have restricted access to platform features.',
              ]
            },
            {
              icon: Target,
              step: '02',
              title: 'Enter your Stableford scores',
              content: [
                'Log your Stableford scores after each round — valid range is 1 to 45 points.',
                'The platform keeps a rolling record of your latest 5 scores.',
                'Each score must have a date. When you add a 6th score, your oldest is automatically replaced.',
                'Scores are displayed in reverse chronological order (most recent first).',
                'You can edit or delete any of your stored scores at any time.',
              ]
            },
            {
              icon: Trophy,
              step: '03',
              title: 'Monthly draws & prizes',
              content: [
                '5 numbers are drawn each month from the Stableford score range (1–45).',
                'The draw can use random generation or an algorithmic weighted method.',
                'Your scores are compared against the drawn numbers.',
                'Match 3 numbers → win from the 25% prize pool tier.',
                'Match 4 numbers → win from the 35% prize pool tier.',
                'Match all 5 numbers → win from the 40% jackpot tier.',
                'If multiple users win the same tier, the prize is split equally.',
                'If no one matches 5 numbers, the jackpot rolls over to next month.',
              ]
            },
            {
              icon: Heart,
              step: '04',
              title: 'Charity impact',
              content: [
                'Select your preferred charity when you sign up — you can change it any time.',
                'A minimum of 10% of your subscription fee is donated to your chosen charity.',
                'You can voluntarily increase your charity percentage up to 100%.',
                'You can also make independent donations unconnected to your subscription.',
                'We publish contribution totals publicly so you can see your collective impact.',
              ]
            },
          ].map(section => (
            <div key={section.step} className="flex gap-6">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-xl bg-green-400/15 border border-green-400/25 flex items-center justify-center flex-shrink-0">
                  <section.icon className="w-5 h-5 text-green-400" />
                </div>
                <div className="w-px flex-1 bg-white/5 mt-3" />
              </div>
              <div className="pb-10 flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-green-400/60 font-mono">{section.step}</span>
                  <h2 className="font-display text-xl font-bold">{section.title}</h2>
                </div>
                <ul className="space-y-2">
                  {section.content.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted">
                      <CheckCircle className="w-4 h-4 text-green-400/50 flex-shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Prize table */}
        <div className="card mb-12">
          <h3 className="font-display text-xl font-bold mb-5">Prize pool breakdown</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/8">
                  <th className="text-left text-xs text-muted uppercase tracking-wider pb-3 pr-6 font-medium">Tier</th>
                  <th className="text-left text-xs text-muted uppercase tracking-wider pb-3 pr-6 font-medium">Pool Share</th>
                  <th className="text-left text-xs text-muted uppercase tracking-wider pb-3 pr-6 font-medium">Prize Split</th>
                  <th className="text-left text-xs text-muted uppercase tracking-wider pb-3 font-medium">Rollover?</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {[
                  { tier: '5-Number Match 🏆', share: '40%', split: 'Equal among all 5-match winners', rollover: 'Yes — jackpot' },
                  { tier: '4-Number Match 🥈', share: '35%', split: 'Equal among all 4-match winners', rollover: 'No' },
                  { tier: '3-Number Match 🥉', share: '25%', split: 'Equal among all 3-match winners', rollover: 'No' },
                ].map(row => (
                  <tr key={row.tier}>
                    <td className="py-3 pr-6 font-medium">{row.tier}</td>
                    <td className="py-3 pr-6 text-green-400 font-semibold">{row.share}</td>
                    <td className="py-3 pr-6 text-muted">{row.split}</td>
                    <td className="py-3 text-muted">{row.rollover}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link href="/subscribe" className="btn-primary text-base px-8 py-4">
            Join GreenHeart <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </main>
      <Footer />
    </>
  );
}
