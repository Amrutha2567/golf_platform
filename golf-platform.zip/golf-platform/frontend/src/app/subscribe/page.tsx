'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Heart, Check, Loader2, ArrowRight, Star } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { apiFetch } from '@/lib/api';
import type { Charity } from '@/lib/types';
import toast from 'react-hot-toast';

type Plan = 'monthly' | 'yearly';

export default function SubscribePage() {
  const router   = useRouter();
  const supabase = createClient();

  const [plan,      setPlan]      = useState<Plan>('monthly');
  const [charities, setCharities] = useState<Charity[]>([]);
  const [charity,   setCharity]   = useState('');
  const [pct,       setPct]       = useState(10);
  const [step,      setStep]      = useState<'plan' | 'charity' | 'account'>('plan');
  const [loading,   setLoading]   = useState(false);

  // Account fields (for new users)
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [name,     setName]     = useState('');
  const [existingUser, setExistingUser] = useState(false);

  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/charities`)
      .then(r => r.json())
      .then(setCharities)
      .catch(() => {});

    supabase.auth.getUser().then(({ data }) => {
      if (data.user) setExistingUser(true);
    });
  }, []);

  const handleCheckout = async () => {
    setLoading(true);
    try {
      let token: string | undefined;

      if (!existingUser) {
        // Register user first
        const { data: authData, error: authErr } = await supabase.auth.signUp({ email, password });
        if (authErr) throw authErr;

        // Create profile via API
        token = authData.session?.access_token;
        await apiFetch('/api/auth/register', {
          method: 'POST',
          token,
          body: JSON.stringify({ email, password, full_name: name, charity_id: charity || null, charity_percentage: pct })
        });
      } else {
        const { data } = await supabase.auth.getSession();
        token = data.session?.access_token;

        // Update charity selection if provided
        if (charity) {
          await apiFetch('/api/auth/me', {
            method: 'PATCH',
            token,
            body: JSON.stringify({ charity_id: charity, charity_percentage: pct })
          });
        }
      }

      // Create Stripe checkout session
      const { url } = await apiFetch<{ url: string }>('/api/subscriptions/checkout', {
        method: 'POST',
        token,
        body: JSON.stringify({ plan })
      });

      window.location.href = url;
    } catch (err: any) {
      toast.error(err.message || 'Something went wrong');
      setLoading(false);
    }
  };

  const PLANS = {
    monthly: { label: 'Monthly', price: '€9.99', period: '/month', saving: null },
    yearly:  { label: 'Yearly',  price: '€99',   period: '/year',  saving: 'Save 17%' },
  };

  return (
    <div className="min-h-screen px-4 py-16">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-green-700 flex items-center justify-center">
              <Heart className="w-4 h-4 text-black" fill="currentColor" />
            </div>
            <span className="font-display text-xl font-bold">Green<span className="text-green-400">Heart</span></span>
          </Link>
          <h1 className="section-title mb-2">Choose your plan</h1>
          <p className="text-muted text-sm">Join thousands of golfers making a difference every month.</p>
        </div>

        {/* Step indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {['plan', 'charity', 'account'].map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                step === s ? 'bg-green-400 text-black' :
                ['plan','charity','account'].indexOf(step) > i ? 'bg-green-400/30 text-green-400' :
                'bg-white/10 text-white/30'
              }`}>
                {['plan','charity','account'].indexOf(step) > i ? <Check className="w-3 h-3" /> : i + 1}
              </div>
              {i < 2 && <div className={`w-12 h-px ${['plan','charity','account'].indexOf(step) > i ? 'bg-green-400/50' : 'bg-white/10'}`} />}
            </div>
          ))}
        </div>

        {/* Step 1 — Plan */}
        {step === 'plan' && (
          <div className="space-y-4 page-enter">
            {(Object.entries(PLANS) as [Plan, typeof PLANS.monthly][]).map(([key, val]) => (
              <button
                key={key}
                onClick={() => setPlan(key)}
                className={`w-full card text-left transition-all duration-200 ${
                  plan === key ? 'border-green-400/60 bg-green-400/5 ring-green shadow-[0_0_20px_rgba(34,197,94,0.1)]' : 'hover:border-green-400/25'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${plan === key ? 'border-green-400' : 'border-white/20'}`}>
                      {plan === key && <div className="w-2.5 h-2.5 rounded-full bg-green-400" />}
                    </div>
                    <div>
                      <p className="font-semibold">{val.label}</p>
                      <p className="text-xs text-muted">Billed {key === 'monthly' ? 'every month' : 'once per year'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-2xl font-bold text-green-400">{val.price}<span className="text-sm text-muted font-normal">{val.period}</span></p>
                    {val.saving && <span className="badge-green text-xs">{val.saving}</span>}
                  </div>
                </div>
                {key === 'yearly' && (
                  <div className="mt-3 flex items-center gap-1.5 text-xs text-green-400/70">
                    <Star className="w-3 h-3" />
                    Best value — equivalent to 2 months free
                  </div>
                )}
              </button>
            ))}

            <div className="card p-4 space-y-2">
              <h4 className="text-sm font-semibold mb-2 text-white/70">What's included</h4>
              {['Access to monthly prize draws', 'Score tracking (5 Stableford scores)', 'Charity contribution from your sub', 'Draw results & winner history', 'Member dashboard'].map(f => (
                <div key={f} className="flex items-center gap-2 text-sm text-white/50">
                  <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" />
                  {f}
                </div>
              ))}
            </div>

            <button onClick={() => setStep('charity')} className="btn-primary w-full py-4 text-base">
              Continue <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Step 2 — Charity */}
        {step === 'charity' && (
          <div className="space-y-4 page-enter">
            <div className="card p-5">
              <h3 className="font-semibold mb-1">Choose a charity</h3>
              <p className="text-xs text-muted mb-4">A minimum of 10% of your subscription goes to your chosen charity.</p>

              <div className="grid grid-cols-2 gap-3 mb-5">
                {charities.slice(0, 6).map(c => (
                  <button
                    key={c.id}
                    onClick={() => setCharity(c.id)}
                    className={`p-3 rounded-xl border text-left transition-all text-sm ${
                      charity === c.id
                        ? 'border-green-400/60 bg-green-400/8 text-green-300'
                        : 'border-white/10 hover:border-white/25 text-white/60'
                    }`}
                  >
                    <p className="font-medium text-xs leading-tight">{c.name}</p>
                  </button>
                ))}
              </div>

              <div>
                <label className="text-xs text-muted block mb-2">
                  Donation percentage: <span className="text-green-400 font-semibold">{pct}%</span>
                  {pct > 10 && <span className="text-green-400/60 ml-1">(thank you! 💚)</span>}
                </label>
                <input
                  type="range"
                  min={10}
                  max={100}
                  step={5}
                  value={pct}
                  onChange={e => setPct(Number(e.target.value))}
                  className="w-full accent-green-400"
                />
                <div className="flex justify-between text-xs text-muted mt-1">
                  <span>10% (min)</span>
                  <span>100%</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep('plan')} className="btn-outline flex-1 py-3">Back</button>
              <button onClick={() => setStep('account')} className="btn-primary flex-1 py-3">
                Continue <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3 — Account */}
        {step === 'account' && (
          <div className="space-y-4 page-enter">
            {existingUser ? (
              <div className="card p-5 text-center">
                <div className="w-10 h-10 rounded-full bg-green-400/15 border border-green-400/30 flex items-center justify-center mx-auto mb-3">
                  <Check className="w-5 h-5 text-green-400" />
                </div>
                <p className="font-semibold mb-1">Already signed in</p>
                <p className="text-sm text-muted">Proceeding to payment...</p>
              </div>
            ) : (
              <div className="card p-5 space-y-4">
                <h3 className="font-semibold">Create your account</h3>
                <input type="text" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} className="input-field" />
                <input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} className="input-field" />
                <input type="password" placeholder="Password (min 8 characters)" value={password} onChange={e => setPassword(e.target.value)} className="input-field" />
                <p className="text-xs text-muted">
                  Already have an account?{' '}
                  <Link href="/login" className="text-green-400 hover:text-green-300 transition-colors">Sign in</Link>
                </p>
              </div>
            )}

            {/* Summary */}
            <div className="card p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted">Plan</span>
                <span className="font-medium capitalize">{plan} — {PLANS[plan].price}{PLANS[plan].period}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Charity</span>
                <span className="font-medium">{charities.find(c => c.id === charity)?.name || 'None selected'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Donation %</span>
                <span className="font-medium text-green-400">{pct}%</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep('charity')} className="btn-outline flex-1 py-3">Back</button>
              <button
                onClick={handleCheckout}
                disabled={loading || (!existingUser && (!email || !password || !name))}
                className="btn-primary flex-1 py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Pay Securely <ArrowRight className="w-4 h-4" /></>}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
