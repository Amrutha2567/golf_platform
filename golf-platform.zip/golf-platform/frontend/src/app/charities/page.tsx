import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Heart, ExternalLink, Star, Calendar } from 'lucide-react';
import type { Charity } from '@/lib/types';

async function getCharities(): Promise<Charity[]> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/charities`, { cache: 'no-store' });
    return res.ok ? res.json() : [];
  } catch {
    return [];
  }
}

export default async function CharitiesPage() {
  const charities = await getCharities();
  const featured  = charities.filter(c => c.is_featured);
  const rest      = charities.filter(c => !c.is_featured);

  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">

        {/* Header */}
        <div className="text-center mb-14">
          <p className="text-green-400 text-xs font-semibold uppercase tracking-widest mb-3">Every round matters</p>
          <h1 className="section-title mb-4">The causes you're supporting</h1>
          <p className="text-muted max-w-md mx-auto text-sm leading-relaxed">
            A portion of every subscription goes directly to your chosen charity. Select one when you subscribe — you can change it anytime.
          </p>
        </div>

        {/* Featured charities */}
        {featured.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-5">
              <Star className="w-4 h-4 text-yellow-400" fill="currentColor" />
              <h2 className="text-sm font-semibold text-white/60 uppercase tracking-widest">Featured</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-5">
              {featured.map(c => (
                <CharityCard key={c.id} charity={c} featured />
              ))}
            </div>
          </div>
        )}

        {/* All charities */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rest.map(c => (
            <CharityCard key={c.id} charity={c} />
          ))}
        </div>

        {charities.length === 0 && (
          <div className="text-center py-20 text-muted">
            <Heart className="w-8 h-8 mx-auto mb-3 opacity-30" />
            <p>Charities coming soon.</p>
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}

function CharityCard({ charity, featured }: { charity: Charity; featured?: boolean }) {
  return (
    <div className={`card hover:border-green-400/25 transition-all duration-300 group ${featured ? 'p-7' : ''}`}>
      <div className="flex items-start gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400/20 to-green-600/10 border border-green-400/20 flex items-center justify-center flex-shrink-0">
          <Heart className="w-5 h-5 text-green-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm truncate">{charity.name}</h3>
            {charity.is_featured && (
              <Star className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" fill="currentColor" />
            )}
          </div>
          {charity.total_raised > 0 && (
            <p className="text-xs text-green-400 mt-0.5">€{charity.total_raised.toLocaleString()} raised</p>
          )}
        </div>
      </div>

      {charity.description && (
        <p className="text-sm text-muted leading-relaxed mb-4 line-clamp-3">{charity.description}</p>
      )}

      {/* Upcoming events */}
      {(charity.charity_events || []).length > 0 && (
        <div className="border-t border-white/5 pt-3 mb-4">
          <p className="text-xs text-white/30 uppercase tracking-wider mb-2">Upcoming</p>
          {charity.charity_events!.slice(0, 2).map(ev => (
            <div key={ev.id} className="flex items-center gap-2 text-xs text-muted mb-1">
              <Calendar className="w-3 h-3 text-green-400/60 flex-shrink-0" />
              <span className="truncate">{ev.title} — {new Date(ev.event_date).toLocaleDateString('en-IE', { day: 'numeric', month: 'short' })}</span>
            </div>
          ))}
        </div>
      )}

      {charity.website_url && (
        <a
          href={charity.website_url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-xs text-green-400/60 hover:text-green-400 transition-colors"
        >
          Visit website <ExternalLink className="w-3 h-3" />
        </a>
      )}
    </div>
  );
}
