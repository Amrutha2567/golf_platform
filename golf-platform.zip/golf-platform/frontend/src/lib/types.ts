// ── Enums ────────────────────────────────────────────────────

export type SubscriptionPlan   = 'monthly' | 'yearly';
export type SubscriptionStatus = 'active' | 'inactive' | 'cancelled' | 'lapsed';
export type DrawStatus         = 'draft' | 'simulation' | 'published';
export type DrawLogic          = 'random' | 'algorithmic';
export type PaymentStatus      = 'pending' | 'paid' | 'rejected';
export type WinnerTier         = 'match_5' | 'match_4' | 'match_3';

// ── Domain Models ────────────────────────────────────────────

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  country: string;
  is_admin: boolean;
  charity_id: string | null;
  charity_percentage: number;
  created_at: string;
  updated_at: string;
  // joined
  charities?: Charity;
  subscriptions?: Subscription[];
}

export interface Subscription {
  id: string;
  user_id: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  amount_paid: number;
  currency: string;
  current_period_start: string | null;
  current_period_end: string | null;
  cancelled_at: string | null;
  created_at: string;
}

export interface GolfScore {
  id: string;
  user_id: string;
  score: number;
  played_date: string;
  created_at: string;
}

export interface Charity {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  logo_url: string | null;
  banner_url: string | null;
  website_url: string | null;
  is_featured: boolean;
  is_active: boolean;
  total_raised: number;
  created_at: string;
  charity_events?: CharityEvent[];
}

export interface CharityEvent {
  id: string;
  charity_id: string;
  title: string;
  description: string | null;
  event_date: string;
  location: string | null;
}

export interface Draw {
  id: string;
  month: number;
  year: number;
  logic: DrawLogic;
  status: DrawStatus;
  drawn_numbers: number[];
  jackpot_rolled_over: boolean;
  rollover_amount: number;
  total_pool: number;
  pool_match5: number;
  pool_match4: number;
  pool_match3: number;
  published_at: string | null;
  created_at: string;
}

export interface DrawParticipant {
  id: string;
  draw_id: string;
  user_id: string;
  scores: number[];
  matched_count: number;
  tier: WinnerTier | null;
}

export interface Winner {
  id: string;
  draw_id: string;
  user_id: string;
  tier: WinnerTier;
  prize_amount: number;
  proof_url: string | null;
  payment_status: PaymentStatus;
  verified_at: string | null;
  paid_at: string | null;
  admin_notes: string | null;
  created_at: string;
  // joined
  profiles?: Profile;
  draws?: Draw;
}

export interface CharityContribution {
  id: string;
  user_id: string;
  charity_id: string;
  amount: number;
  percentage: number;
  period_month: number;
  period_year: number;
  created_at: string;
}

// ── API Response Shapes ──────────────────────────────────────

export interface AdminStats {
  totalUsers: number;
  activeSubscribers: number;
  totalDraws: number;
  totalSubscriptionRevenue: number;
  totalPrizesPaid: number;
  totalCharityRaised: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}

// ── UI Helpers ───────────────────────────────────────────────

export const MONTH_NAMES = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
];

export const TIER_LABELS: Record<WinnerTier, string> = {
  match_5: '5-Number Match 🏆',
  match_4: '4-Number Match 🥈',
  match_3: '3-Number Match 🥉',
};

export const TIER_COLORS: Record<WinnerTier, string> = {
  match_5: 'badge-yellow',
  match_4: 'badge-blue',
  match_3: 'badge-green',
};

export const STATUS_COLORS: Record<PaymentStatus, string> = {
  pending: 'badge-yellow',
  paid:    'badge-green',
  rejected:'badge-red',
};
