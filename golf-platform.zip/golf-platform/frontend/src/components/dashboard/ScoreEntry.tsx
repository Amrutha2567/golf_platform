'use client';

import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Check, X, Calendar, Loader2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { apiFetch } from '@/lib/api';
import type { GolfScore } from '@/lib/types';
import toast from 'react-hot-toast';

export default function ScoreEntry() {
  const supabase = createClient();
  const [scores,   setScores]   = useState<GolfScore[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [adding,   setAdding]   = useState(false);
  const [editId,   setEditId]   = useState<string | null>(null);
  const [token,    setToken]    = useState<string>('');

  // New / edit form state
  const [formScore, setFormScore] = useState('');
  const [formDate,  setFormDate]  = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      const t = data.session?.access_token || '';
      setToken(t);
      if (t) loadScores(t);
    });
  }, []);

  const loadScores = async (t: string) => {
    setLoading(true);
    try {
      const data = await apiFetch<GolfScore[]>('/api/scores', { token: t });
      setScores(data);
    } catch (err: any) {
      toast.error('Failed to load scores');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    const s = parseInt(formScore);
    if (isNaN(s) || s < 1 || s > 45) {
      toast.error('Score must be between 1 and 45');
      return;
    }
    setLoading(true);
    try {
      await apiFetch('/api/scores', {
        method: 'POST',
        token,
        body: JSON.stringify({ score: s, played_date: formDate })
      });
      toast.success('Score added!');
      setAdding(false);
      setFormScore('');
      setFormDate(new Date().toISOString().split('T')[0]);
      await loadScores(token);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: string) => {
    const s = parseInt(formScore);
    if (isNaN(s) || s < 1 || s > 45) {
      toast.error('Score must be between 1 and 45');
      return;
    }
    setLoading(true);
    try {
      await apiFetch(`/api/scores/${id}`, {
        method: 'PUT',
        token,
        body: JSON.stringify({ score: s, played_date: formDate })
      });
      toast.success('Score updated');
      setEditId(null);
      setFormScore('');
      await loadScores(token);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this score?')) return;
    setLoading(true);
    try {
      await apiFetch(`/api/scores/${id}`, { method: 'DELETE', token });
      toast.success('Score deleted');
      await loadScores(token);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (score: GolfScore) => {
    setEditId(score.id);
    setFormScore(String(score.score));
    setFormDate(score.played_date);
    setAdding(false);
  };

  const cancelEdit = () => {
    setEditId(null);
    setFormScore('');
    setFormDate(new Date().toISOString().split('T')[0]);
  };

  const ScoreColor = (s: number) => {
    if (s >= 36) return 'text-yellow-400 border-yellow-400/40 bg-yellow-400/10';
    if (s >= 28) return 'text-green-400 border-green-400/40 bg-green-400/10';
    if (s >= 20) return 'text-blue-400 border-blue-400/40 bg-blue-400/10';
    return 'text-white/50 border-white/10 bg-white/5';
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="font-display text-lg font-semibold">My Scores</h3>
          <p className="text-xs text-muted mt-0.5">Rolling last 5 Stableford scores</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted">{scores.length}/5</span>
          {!adding && (
            <button
              onClick={() => { setAdding(true); setEditId(null); }}
              className="btn-primary py-1.5 px-3 text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> Add Score
            </button>
          )}
        </div>
      </div>

      {/* Add form */}
      {adding && (
        <div className="mb-4 p-4 rounded-xl border border-green-400/25 bg-green-400/5 space-y-3">
          <p className="text-xs font-medium text-green-400">New Score</p>
          <div className="flex gap-3">
            <input
              type="number"
              placeholder="Score (1–45)"
              min={1} max={45}
              value={formScore}
              onChange={e => setFormScore(e.target.value)}
              className="input-field flex-1"
            />
            <div className="relative flex-1">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
              <input
                type="date"
                value={formDate}
                onChange={e => setFormDate(e.target.value)}
                className="input-field pl-9"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={handleAdd} className="btn-primary py-1.5 px-4 text-xs">
              <Check className="w-3.5 h-3.5" /> Save
            </button>
            <button onClick={() => setAdding(false)} className="btn-outline py-1.5 px-4 text-xs">
              <X className="w-3.5 h-3.5" /> Cancel
            </button>
          </div>
        </div>
      )}

      {/* Score list */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-5 h-5 animate-spin text-green-400/60" />
        </div>
      ) : scores.length === 0 ? (
        <div className="text-center py-10">
          <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mx-auto mb-3">
            <span className="text-2xl">⛳</span>
          </div>
          <p className="text-sm text-muted">No scores yet</p>
          <p className="text-xs text-muted/60 mt-1">Add your first Stableford score to get started</p>
        </div>
      ) : (
        <div className="space-y-2">
          {scores.map((score, idx) => (
            <div key={score.id}>
              {editId === score.id ? (
                <div className="p-3 rounded-xl border border-green-400/25 bg-green-400/5 space-y-3">
                  <div className="flex gap-3">
                    <input
                      type="number"
                      min={1} max={45}
                      value={formScore}
                      onChange={e => setFormScore(e.target.value)}
                      className="input-field flex-1 text-sm py-2"
                    />
                    <div className="relative flex-1">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
                      <input
                        type="date"
                        value={formDate}
                        onChange={e => setFormDate(e.target.value)}
                        className="input-field pl-9 text-sm py-2"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => handleEdit(score.id)} className="btn-primary py-1 px-3 text-xs">
                      <Check className="w-3.5 h-3.5" /> Update
                    </button>
                    <button onClick={cancelEdit} className="btn-outline py-1 px-3 text-xs">
                      <X className="w-3.5 h-3.5" /> Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/3 group transition-colors">
                  <div className={`w-10 h-10 rounded-full border flex items-center justify-center text-sm font-bold flex-shrink-0 ${ScoreColor(score.score)}`}>
                    {score.score}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{score.score} pts</p>
                    <p className="text-xs text-muted">{new Date(score.played_date).toLocaleDateString('en-IE', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                  </div>
                  {idx === 0 && (
                    <span className="badge-green text-xs">Latest</span>
                  )}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => startEdit(score)} className="p-1.5 rounded-lg hover:bg-white/8 text-white/40 hover:text-white/70 transition-colors">
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => handleDelete(score.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-white/40 hover:text-red-400 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {scores.length > 0 && (
        <p className="text-xs text-muted/60 mt-4 text-center">
          Adding a new score will automatically remove the oldest one
        </p>
      )}
    </div>
  );
}
