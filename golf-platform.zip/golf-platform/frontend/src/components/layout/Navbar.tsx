'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { Menu, X, Heart, User, LogOut, LayoutDashboard, ShieldCheck } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import type { Profile } from '@/lib/types';

export default function Navbar() {
  const pathname = usePathname();
  const router   = useRouter();
  const supabase = createClient();

  const [open,    setOpen]    = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (!data.user) return;
      supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .single()
        .then(({ data: p }) => setProfile(p));
    });
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    router.push('/');
    router.refresh();
  };

  const navLinks = [
    { href: '/charities', label: 'Charities' },
    { href: '/draws',     label: 'Draws' },
    { href: '/how-it-works', label: 'How It Works' },
  ];

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass border-b border-[rgba(34,197,94,0.12)] shadow-2xl' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-green-700 flex items-center justify-center shadow-[0_0_16px_rgba(34,197,94,0.5)]">
              <Heart className="w-4 h-4 text-black" fill="currentColor" />
            </div>
            <span className="font-display text-xl font-bold tracking-tight">
              Green<span className="text-green-400">Heart</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive(link.href)
                    ? 'text-green-400 bg-green-400/10'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Desktop auth */}
          <div className="hidden md:flex items-center gap-3">
            {profile ? (
              <>
                {profile.is_admin && (
                  <Link href="/admin" className="btn-outline py-2 text-xs gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Admin
                  </Link>
                )}
                <Link href="/dashboard" className="btn-outline py-2 text-xs gap-1.5">
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  Dashboard
                </Link>
                <button onClick={handleSignOut} className="p-2 rounded-lg text-white/40 hover:text-white/70 transition-colors">
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="btn-outline py-2 text-xs">Sign In</Link>
                <Link href="/subscribe" className="btn-primary py-2 text-xs">Subscribe</Link>
              </>
            )}
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 text-white/60 hover:text-white"
            onClick={() => setOpen(!open)}
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden glass border-t border-[rgba(34,197,94,0.1)] px-4 pb-4 pt-2 space-y-1">
          {navLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive(link.href)
                  ? 'text-green-400 bg-green-400/10'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-2 flex flex-col gap-2">
            {profile ? (
              <>
                <Link href="/dashboard" onClick={() => setOpen(false)} className="btn-outline text-sm">Dashboard</Link>
                {profile.is_admin && (
                  <Link href="/admin" onClick={() => setOpen(false)} className="btn-outline text-sm">Admin Panel</Link>
                )}
                <button onClick={handleSignOut} className="btn-outline text-sm">Sign Out</button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setOpen(false)} className="btn-outline text-sm">Sign In</Link>
                <Link href="/subscribe" onClick={() => setOpen(false)} className="btn-primary text-sm">Subscribe</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
