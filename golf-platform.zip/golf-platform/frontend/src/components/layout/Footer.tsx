import Link from 'next/link';
import { Heart, Twitter, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-[rgba(34,197,94,0.1)] bg-[#0a0f0a] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-green-400 to-green-700 flex items-center justify-center">
                <Heart className="w-3.5 h-3.5 text-black" fill="currentColor" />
              </div>
              <span className="font-display text-lg font-bold">
                Green<span className="text-green-400">Heart</span>
              </span>
            </div>
            <p className="text-sm text-white/40 max-w-xs leading-relaxed">
              The golf platform that turns every Stableford score into a chance to win — and a commitment to give.
            </p>
            <div className="flex items-center gap-3 mt-4">
              {[Twitter, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-8 h-8 rounded-lg border border-white/10 flex items-center justify-center text-white/40 hover:text-green-400 hover:border-green-400/40 transition-colors">
                  <Icon className="w-3.5 h-3.5" />
                </a>
              ))}
            </div>
          </div>

          {/* Platform */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/30 mb-3">Platform</h4>
            <ul className="space-y-2">
              {[
                { label: 'How It Works', href: '/how-it-works' },
                { label: 'Draws',        href: '/draws' },
                { label: 'Subscribe',    href: '/subscribe' },
                { label: 'Dashboard',   href: '/dashboard' },
              ].map(item => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-white/40 hover:text-green-400 transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Charities */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/30 mb-3">Giving</h4>
            <ul className="space-y-2">
              {[
                { label: 'Charities',    href: '/charities' },
                { label: 'Impact',       href: '/impact' },
                { label: 'Terms',        href: '/terms' },
                { label: 'Privacy',      href: '/privacy' },
              ].map(item => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-white/40 hover:text-green-400 transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="divider mb-6" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/25">
          <p>© {new Date().getFullYear()} GreenHeart. All rights reserved.</p>
          <p>Built with care by <span className="text-green-400/60">Digital Heroes</span></p>
        </div>
      </div>
    </footer>
  );
}
